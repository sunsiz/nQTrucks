#!/bin/bash

echo Please provide root password

sudo cp /usr/share/pixmaps/wicd_bk/* /usr/share/pixmaps/wicd/
sudo rm -rf /usr/share/pixmaps/wicd_bk

echo DONE
