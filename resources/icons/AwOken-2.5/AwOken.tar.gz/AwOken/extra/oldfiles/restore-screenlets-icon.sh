#!/bin/bash
cd /usr/share/icons/hicolor/scalable/apps
echo Please provide root password

sudo rm screenlets.png
sudo mv screenlets-backup.svg screenlets.svg

echo DONE
